# GameBoostPro Beta,
**Version:** 1.0  
**Author:** ApexOptiTech  
**Product Type:** Windows Game Optimization Tool  
**Executable:** GameBoostPro.exe

---

 backup pc before using, this tool changing computer settings.


Description

GameBoostPro is an all-in-one Windows performance enhancement utility designed specifically for gamers. With a single click, it automatically:

- Enables Ultimate Performance power mode
- Disables telemetry and tracking services
- Turns off Xbox Game Bar and Game DVR
- Adjusts system visuals for maximum performance
- Boosts foreground app responsiveness
- Closes unnecessary background apps (e.g., OneDrive, Discord, Steam)
- Clears standby RAM using `EmptyStandbyList.exe`
- Optimizes TCP/IP settings for better latency
- Disables fullscreen optimizations

Additionally, it allows you to launch your favorite game at high priority directly from the interface.

---

Requirements

- Windows 10 or 11 (64-bit)
- Administrator privileges

HOW TO USE

1. Run `GameBoostPro.exe` as Administrator.
2. (Optional) Enter the path to your game executable and click "Launch Game with High Priority".
3. Click **Optimize for Gaming** and allow the script to complete.
4. Restart your PC for all optimizations to fully apply.

---

Disclaimer

This software is provided "as is" without warranty of any kind. Use at your own risk. Always back up your system before running optimization scripts.

---

© 2025 ApexOptiTech
